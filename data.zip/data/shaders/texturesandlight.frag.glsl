#version 330 core
struct Material {
	sampler2D DIFFUSE1;
	sampler2D SPECULAR1;
	vec3 specularFUCKYOU;
	float shininess;
};

struct DirLight {
	vec3 direction;

	vec3 ambient;
	vec3 diffuse;
	vec3 specular;
};

struct PointLight {
	vec3 position;

	float constant;
	float linear;
	float quadratic;

	vec3 ambient;
	vec3 diffuse;
	vec3 specular;
};

#define MAX_POINTLIGHTS 8

in vec3 Normal;
in vec3 FragPos;
in vec2 TexCoord;

out vec4 FragColor;

uniform DirLight dirLight;
uniform int pointLightNum;
uniform PointLight pointLights[MAX_POINTLIGHTS];

uniform Material material;
uniform vec3 viewPos;

vec3 CalcDirLight(DirLight light, vec3 normal, vec3 viewDir);
vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir);

void main()
{
	vec3 norm = normalize(Normal);
	vec3 viewDir = normalize(viewPos - FragPos);

	vec3 result = CalcDirLight(dirLight, norm, viewDir);
	for (int i = 0; i < pointLightNum; i++)
		result += CalcPointLight(pointLights[i], norm, FragPos, viewDir);

	FragColor = vec4(result, 1.0);
}

vec3 CalcDirLight(DirLight light, vec3 normal, vec3 viewDir)
{
	vec3 lightDir = normalize(-light.direction);
	float diff = max(dot(normal, lightDir), 0.0);

	vec3 reflectDir = reflect(-lightDir, normal);
	float spec = pow(max(dot(viewDir, reflectDir), 0.001), material.shininess);

	vec3 ambient = light.ambient * vec3(texture(material.DIFFUSE1, TexCoord));
	vec3 diffuse = light.diffuse * diff * vec3(texture(material.DIFFUSE1, TexCoord));
	vec3 specular = light.specular * spec * vec3(texture(material.SPECULAR1, TexCoord));
	//vec3 specular = light.specular * spec * material.specularFUCKYOU;
	return (ambient + diffuse + specular);
}

vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir)
{
	vec3 lightDir = normalize(light.position - fragPos);

	float diff = max(dot(normal, lightDir), 0.0);

	vec3 reflectDir = reflect(-lightDir, normal);
	float spec = pow(max(dot(viewDir, reflectDir), 0.001), material.shininess);

	float distance = length(light.position - fragPos);
	float attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));

	vec3 ambient = light.ambient * vec3(texture(material.DIFFUSE1, TexCoord));
	vec3 diffuse = light.diffuse * diff * vec3(texture(material.DIFFUSE1, TexCoord));
	vec3 specular = light.specular * spec * vec3(texture(material.SPECULAR1, TexCoord));
	//vec3 specular = light.specular * spec * material.specularFUCKYOU;

	ambient *= attenuation;
	diffuse *= attenuation;
	specular *= attenuation;

	return (ambient + diffuse + specular);

}